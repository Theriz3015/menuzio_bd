
-- Transação 01: Efetuar pedido
START TRANSACTION;

-- Inserir pedido
INSERT INTO pedido (cliente_id, usuario_id, total) VALUES (1, 1, 90.00);
SET @pedido_id = LAST_INSERT_ID();

-- Savepoint antes dos itens
SAVEPOINT sp_itens;

-- Inserir item e atualizar estoque
INSERT INTO item_pedido (pedido_id, produto_id, quantidade, preco_unitario)
VALUES (@pedido_id, 2, 3, 30.00);

UPDATE estoque SET quantidade = quantidade - 3 WHERE produto_id = 2;

-- Simulação de falha
-- UPDATE estoque SET quantidade = quantidade - 100 WHERE produto_id = 3;

-- Se falhar, desfazer itens:
-- ROLLBACK TO sp_itens;

-- Finalizar pedido
UPDATE pedido SET status = 'em preparo' WHERE id = @pedido_id;

COMMIT;

-- Transação 02: Cancelar pedido
START TRANSACTION;

-- Savepoint para deletar itens
SAVEPOINT sp_cancelar;

-- Restaurar estoque antes de deletar item_pedido
UPDATE estoque SET quantidade = quantidade + 3 WHERE produto_id = 2;

-- Deletar itens
DELETE FROM item_pedido WHERE pedido_id = @pedido_id;

-- Deletar pedido
DELETE FROM pedido WHERE id = @pedido_id;

COMMIT;

-- Transação 03: Reposição de estoque
START TRANSACTION;

-- Savepoint antes da reposição
SAVEPOINT sp_reposicao;

-- Atualizar quantidade
UPDATE estoque SET quantidade = quantidade + 50 WHERE produto_id = 4;

-- Simulação de falha
-- UPDATE estoque SET quantidade = -5 WHERE produto_id = 4;

-- ROLLBACK TO sp_reposicao;

COMMIT;
