
-- Consulta 01: Listar total de pedidos por cliente
SELECT c.id AS cliente_id, c.nome, COUNT(p.id) AS total_pedidos
FROM cliente c
LEFT JOIN pedido p ON p.cliente_id = c.id
GROUP BY c.id, c.nome;

-- Consulta 02: Listar produtos do tipo 'Pizza'
SELECT id, nome, descricao, preco
FROM produto
WHERE categoria = 'Pizza';

-- Consulta 03: Consultar produtos com estoque abaixo de 5
SELECT p.nome, e.quantidade
FROM produto p
JOIN estoque e ON e.produto_id = p.id
WHERE e.quantidade < 5;

-- Consulta 04: Valor total de cada pedido
SELECT p.id AS pedido_id, c.nome AS cliente, SUM(ip.quantidade * ip.preco_unitario) AS total
FROM pedido p
JOIN cliente c ON c.id = p.cliente_id
JOIN item_pedido ip ON ip.pedido_id = p.id
GROUP BY p.id, c.nome;

-- Consulta 05: Top 3 produtos mais vendidos
SELECT pr.nome, SUM(ip.quantidade) AS total_vendido
FROM item_pedido ip
JOIN produto pr ON pr.id = ip.produto_id
GROUP BY pr.nome
ORDER BY total_vendido DESC
LIMIT 3;
